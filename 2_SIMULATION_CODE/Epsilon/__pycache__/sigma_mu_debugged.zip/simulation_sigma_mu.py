import numpy as np
from config import *
from visualization import plot_snapshot

def run_sigma_mu():
    """Main simulation loop with full error protection"""
    # Initialization with guaranteed array outputs
    dx = float(L) / N  # Ensure float division
    x = np.linspace(0, float(L), N)  # Explicit float conversion
    sigma = np.asarray(0.1*np.exp(-(x-L/2)**2/(0.2*L)**2) + 0.01*np.random.rand(N), dtype=np.float64)
    mu = np.zeros_like(sigma, dtype=np.float64)
    
    # Time stepping with safety
    try:
        for step in range(int(float(t_max)/float(dt))):  # Explicit float conversion
            # Protected gradient calculations
            grad_sigma = np.gradient(np.nan_to_num(sigma), dx)
            S = np.abs(grad_sigma) + 1e-12
            
            # σ update (vectorized)
            sigma_update = (
                eta * np.gradient(np.gradient(sigma, dx), dx) +  # Diffusion
                alpha * np.sqrt(np.maximum(sigma, 1e-8)) * S**1.5 -  # Injection
                lam * sigma * S**(2 - beta)  # Decay
            )
            
            # μ update (vectorized)
            mu_update = gamma * sigma * (1 - np.minimum(mu/mu_max, 1.0))
            
            # Apply updates
            sigma = sigma + float(dt) * sigma_update  # Explicit float conversion
            mu = mu + float(dt) * mu_update
            
            # Physical constraints
            sigma = np.clip(sigma, 1e-6, 1.0)
            mu = np.clip(mu, 0.0, mu_max)
            
            # Visualization
            if step % 100 == 0:
                plot_snapshot(x, sigma, mu)
                
    except Exception as e:
        print(f"Crash at step {step}: {str(e)}")
        np.savez('crash_state.npz', 
                 x=x, sigma=sigma, mu=mu,
                 last_dt=dt)
        raise
    
    return sigma, mu
             
             # Dans simulation_sigma_mu.py
if dim == 2:
    X, Y = np.meshgrid(x, x)
    sigma = np.exp(-((X-L/2)**2 + (Y-L/2)**2)/(0.2*L)**2)
    
    # Calculs avec gradient 2D
    grad_sigma_x, grad_sigma_y = np.gradient(sigma, dx, dx)
    S = np.sqrt(grad_sigma_x**2 + grad_sigma_y**2)