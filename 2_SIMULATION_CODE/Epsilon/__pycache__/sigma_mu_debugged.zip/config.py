import numpy as np
try:
    import cupy as cp
except ImportError:
    cp = None
from scipy.ndimage import gaussian_filter
import os
# config.py
from dataclasses import dataclass
@dataclass
class SimulationConfig:
    tmax: float = 10.0    # Doit être un float
    # Grid parameters
    dt = 0.01                  # Must be float
    N: int = 256          # Grid size
    L: float = 2*np.pi    # Domain size
    
    # Physics parameters
    alpha: float = 0.3    # Sigma injection coefficient
    eta: float = 0.1     # Sigma diffusion coefficient
    lmbda: float = 0.1    # Sigma decay coefficient
    nu: float = 0.001     # Viscosity
    beta: float = 0.2     # Non-linearity exponent
    gamma: float = 0.05   # Memory feedback strength
    # Nouveaux paramètres vortex
    kappa = 0.02  # Couplage vortex
    mu_max = 1.0     # Maximum μ capacity
    
    # Time parameters
    tmax: float = 10.0    # Total simulation time
    dt_max: float = 0.1  # Maximum timestep
    dt_min: float = 1e-6  # Minimum timestep (nouveau)
    dx = L / N          # Grid spacing
    # Paramètres de bruit
    add_noise = True
    noise_strength = 0.01  # Intensité du bruit
    
    # n* parameters
    nstar_bounds: tuple = (1.8, 2.8)  # Min/max n* values
    
    # Stabilization options (nouveaux)
    use_spectral_filter: bool = True   # Activer le filtrage spectral
    filter_interval: int = 10         # Intervalle de filtrage
    strict_clipping: bool = True      # Activer le clipping strict
    k_cutoff = 0.8 * (N//2)     # Cutoff wavenumber
    
    # Runtime options
    use_gpu: bool = False
    save_interval = 100  # Pas de sauvegarde
    save_path: str = "results"
    
    # Nouveaux paramètres de stabilisation
    strain_max: float = 10.0          # Valeur maximale pour le strain
    mu_max: float = 5.0               # Valeur maximale pour mu
    sigma_max: float = 20.0           # Valeur maximale pour sigma
    dt_min: float = 1e-5              # Pas de temps minimum absolu
    debug_mode: bool = False          # Mode diagnostic détaillé
    # SIMULATION MODE ###################################
mode = "fluid"  # Options: ["fluid", "sigma_mu"]

# σ-μ PARAMETERS ####################################
# Core dynamics
eta = 0.1       # Diffusion coefficient (σ)
alpha = 0.3     # Injection strength (σ)
beta = 0.1      # Nonlinear decay exponent (σ)
gamma = 0.05    # Growth rate (μ)
mu_max = 1.0    # Maximum μ capacity

# Diagnostics
plot_phase = True  # Toggle phase portrait plotting