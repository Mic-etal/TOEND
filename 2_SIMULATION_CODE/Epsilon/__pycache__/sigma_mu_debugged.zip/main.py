import numpy as np
try:
    import cupy as cp
except ImportError:
    cp = None
    
from config import SimulationConfig
from simulation import EntropicNS2DSimulation  # Correct class name
from physics import PhysicsCore
from operators import PhysicsOperators
from time_integration import TimeIntegrator
from visualization import Visualizer
from config import mode

def main():
    if mode == "sigma_mu":
        from simulation_sigma_mu import run_sigma_mu
        run_sigma_mu()
    else:
        from simulation import run_simulation
        run_simulation()
        
def run_simulation():
    config = SimulationConfig(N=128, tmax=5.0,debug_mode=True, dt_min=1e-4)
    sim = EntropicNS2DSimulation(config)
    ops = PhysicsOperators(config, sim.grid)
    physics = PhysicsCore(config, ops)
    integrator = TimeIntegrator(config, physics, ops)
    visualizer = Visualizer(config)

    # Sauvegarde initiale
    visualizer.save_snapshot(sim.fields, suffix="_init")
    
    try:
        final_fields, diagnostics = integrator.run(sim.fields, sim.diagnostics)
        visualizer.save_snapshot(final_fields)
        visualizer.plot_diagnostics(diagnostics)
    except Exception as e:
        print(f"\nSimulation failed completely: {str(e)}")
        # Sauvegarde d'urgence
        visualizer.save_snapshot(sim.fields, suffix="_crash")
        raise


if __name__ == "__main__":
    run_simulation()